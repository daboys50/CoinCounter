﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.Collections.Generic;

namespace countingImage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select an Image",
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

             
                pictureBox.Image = Image.FromFile(filePath);

                
                string result = ProcessImage(filePath);

            
                lblResult.Text = result;
            }
        }

        private string ProcessImage(string imagePath)
        {
            
            Mat img = CvInvoke.Imread(imagePath, ImreadModes.Color);

            
            Mat grayImg = new Mat();
            CvInvoke.CvtColor(img, grayImg, ColorConversion.Bgr2Gray);

            
            Mat blurredImg = new Mat();
            CvInvoke.GaussianBlur(grayImg, blurredImg, new Size(5, 5), 1.5);

           
            Mat edges = new Mat();
            CvInvoke.Canny(blurredImg, edges, 50, 150);

            
            CircleF[] circles = CvInvoke.HoughCircles(edges, HoughType.Gradient, 1, 20, 100, 30, 10, 50);

            
            Dictionary<string, int> coinValues = new Dictionary<string, int>
            {
                { "10", 0 }, // 10 centavos
                { "25", 0 }, // 25 centavos
                { "1", 0 }   // 1 peso
            };

            foreach (var circle in circles)
            {
                double radius = circle.Radius;

                
                if (radius < 15) 
                    coinValues["10"]++;
                else if (radius < 25) 
                    coinValues["25"]++;
                else
                    coinValues["1"]++;
            }

         
            int totalValue = (coinValues["10"] * 10) + (coinValues["25"] * 25) + (coinValues["1"] * 100);

            
            return $"Coin Counts:\n" +
                   $"10 centavos: {coinValues["10"]}\n" +
                   $"25 centavos: {coinValues["25"]}\n" +
                   $"1 peso: {coinValues["1"]}\n" +
                   $"Total Value: {totalValue} centavos";
        }
    }
}
